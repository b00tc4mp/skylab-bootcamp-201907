module.exports = {
    createChat: require('./create-chat'),
    // deleteChat: require('./delete-chat')
    updateChat: require('./update-chat'),
    retrieveAllChats: require('./retrieve-all-chats'),
    retrieveChat: require('./retrieve-chat')
}
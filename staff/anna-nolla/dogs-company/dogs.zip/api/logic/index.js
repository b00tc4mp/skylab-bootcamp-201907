module.exports = {
    ...require('./user'),
    ...require('./pet'),
    ...require('./chat'),
    ...require('./notification'),
    ...require('./geolocation')
}
module.exports = {
    registerPet: require('./register-pet'),
    retrieveAllPets: require('./retrieve-all-pets'),
    unregisterPet: require('./unregister-pet'),
    retrievePet: require('./retrieve-pet'),
    updatePet: require('./update-pet')
}
module.exports = {
    createNotification: require('./create-notification'),
    deleteNotification: require('./delete-notification'),
    updateNotification: require('./update-notification'),
    retrieveNotification: require('./retrieve-notification')
}
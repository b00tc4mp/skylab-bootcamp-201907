module.exports = {
    updateStatic: require('./update-static'),
    updateDinamic: require('./update-dinamic'),
    retrieveAllStatic: require('./retrieve-all-static'),
    retrieveAllDinamic: require('./retrieve-all-dinamic')
}
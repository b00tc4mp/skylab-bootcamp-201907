 
module.exports = {
    createChat: require('./create-chat'),
    retrieveAllChats: require('./retrieve-all-chats'),
    retrieveChat: require('./retrieve-chat'),
    //deleteChat: require('./delete-chat'),
    updateChat: require('./update-chat')
}
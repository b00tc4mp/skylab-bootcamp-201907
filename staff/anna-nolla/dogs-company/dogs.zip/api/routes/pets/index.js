 
module.exports = {
    registerPet: require('./register-pet'),
    retrieveAllPets: require('./retrieve-all-pets'),
    retrievePet: require('./retrieve-pet'),
    unregisterPet: require('./unregister-pet'),
    updatePet: require('./update-pet')
}
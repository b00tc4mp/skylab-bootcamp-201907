module.exports = {
    retrieveDinamic: require('./retrieve-dinamic'),
    updateDinamic: require('./update-dinamic'),
    retrieveStatic: require('./retrieve-static'),
    updateStatic: require('./update-static')
}
module.exports = {
    models: require('./models'),
    database: require('./database')
}
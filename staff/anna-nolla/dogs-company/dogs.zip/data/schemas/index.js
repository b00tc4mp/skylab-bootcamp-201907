 
module.exports = {
    user: require('./user'),
    pet: require('./pet'),
    chat: require('./chat'),
    message: require('./message'),
    notification: require('./notification')
}
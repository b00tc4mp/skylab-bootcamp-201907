# Dogs & Company

## Introduction

Create an app to connect all dog walkers that want to socialize.

![Introduction](img/introduction.png)

### Use Case

### Flowchart

![Flow](img/flow.png)

### Blocks

![Blocks](img/blocks.png)



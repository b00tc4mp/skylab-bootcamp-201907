 /**
 * saves the token in the sesion state
 * 
 * @param {string} this.__token__
 * 
 */

export default function () {
    return !!this.__token__
}
'use strict';

/**
 * Data
 */

var users = new Curray();

users.push({name: "l", surname: "a", email: "a@li.com", password: "1"});

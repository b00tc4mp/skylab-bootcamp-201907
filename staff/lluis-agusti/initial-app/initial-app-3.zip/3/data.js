'use strict';

/**
 * Data
 */

var users = new Curray();
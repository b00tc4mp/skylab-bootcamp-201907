'use strict';

/**
 * Data
 */

var users = new Curray();

users.push({
    name: 'Manuel',
    surname: 'Barzi',
    email: 'manuelbarzi@gmail.com',
    password: '123'
});
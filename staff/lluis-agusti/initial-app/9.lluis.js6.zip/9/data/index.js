/**
 * Data
 */

const users = new Curray()

users.push({
    name: 'l',
    surname: 'a',
    email: 'a@gmail.com',
    password: '1'
})

// passar a es6!!! va en el contructor!!!! 12 14 vba en el costructor

// class Curray {

//     constructor() {


//         this.length = 0;

//         if (arguments.length === 1) {
//             this.length = arguments[0];
//         } else if (arguments.length > 1) {
//             for (var i = 0; i < arguments.length; i++) {
//                 this[i] = arguments[i];
//             }
//             this.length = arguments.length;
//         }
//  }
// }







 /**
  * DIY Array, i.e. Currate ese Array!.
  * 
  * @version 1.1.0
  */

 function Curray() {
     this.length = 0;

     if (arguments.length === 1) {
         this.length = arguments[0];
     } else if (arguments.length > 1) {
         for (var i = 0; i < arguments.length; i++) {
             this[i] = arguments[i];
             // this.push(arguments[i]); // TRY not to depend on push here.
         }
         this.length = arguments.length;
     }
 }



Curray.prototype.push = function (element) {
    this[this.length++] = element;

    return this.length;
};

Curray.prototype.pop = function() {
    var last = this[--this.length];

    delete this[this.length];

    return last;
};

Curray.prototype.forEach = function(expression) {
    if (arguments.length === 0) throw TypeError('missing argument 0 when calling function forEach');

    if (!(expression instanceof Function)) throw TypeError(expression + ' is not a function');

    for (var i = 0; i < this.length; i++)
        expression(this[i], i, this);
};

Curray.prototype.find = function(expression) {
    if (arguments.length === 0) throw TypeError('missing argument 0 when calling function forEach');

    if (!(expression instanceof Function)) throw TypeError(expression + ' is not a function');

    for (var i = 0; i < this.length; i++) {
        var element = this[i];
        if (expression(this[i], i, this)) return element;
    }
}
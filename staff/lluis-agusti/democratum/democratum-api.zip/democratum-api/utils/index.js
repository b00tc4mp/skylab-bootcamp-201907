module.exports = {
    registerUser: require('../logic/register-user'),
    authenticateUser: require('../logic/authenticate-user')
}
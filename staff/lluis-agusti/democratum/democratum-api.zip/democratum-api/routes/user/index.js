module.exports = {
    registerUser: require('./register'),
    authenticateUser: require('./authenticate'),
    //retrieve : require('./retrieve'),
    updateUser: require('./update')
    //unregister : require('./unregister')
}


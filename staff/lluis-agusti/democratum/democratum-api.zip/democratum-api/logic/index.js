module.exports = {
    registerUser: require('./user/register'),
    authenticateUser: require('./user/authenticate'),
    updateUser: require('./user/update'),
    newPoll: require('./poll/new-poll'),
    updatePoll: require('./poll/update-poll'),
    listApproved: require('./poll/list-approved'),
    listRejected: require('./poll/list-expired'),
    listExpired: require('./poll/list-pending'),
    listPending: require('./poll/list-rejected'),
    votePoll: require('./poll/vote-poll')
}
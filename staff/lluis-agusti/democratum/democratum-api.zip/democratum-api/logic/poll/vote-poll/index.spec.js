const logic = require('../..')
const { expect } = require('chai')
const { models , mongoose } = require('democratum-data')
const { User, Poll } = models

describe.only('logic - vote poll', () => {
    before(() => mongoose.connect('mongodb://localhost/democratum-test',  { useNewUrlParser: true }))

    let cityPollId, authorId, question, optionA, optionB, description, expiryDate, imagePoll, positives, negatives, pollStatus, pollId
    let cityUserId, fullname, address, documentId, email, imgDocId, password, participatedPolls, proposedPolls, userRole, userId

    beforeEach(async() => {
        await Poll.deleteMany()
        await User.deleteMany()

        cityId = `cityID-${Math.random()}`

        authorId = `vehmodel-${Math.random()}`
        question = `question-${Math.random()}`
        optionA = `optiona-${Math.random()}`
        optionB = `optionb-${Math.random()}`
        description = `description-${Math.random()}`
        expiryDate = new Date()
        imagePoll = `image-${Math.random()}`
        positives = 1
        negatives = 1
        pollStatus = 'pending'

        fullname = `fullname-${Math.random()}`
        address = `address-${Math.random()}`
        documentId = `documentid-${Math.random()}@domain.com`
        email = `email@-${Math.random()}.com`
        imgDocId = `imgdocid-${Math.random()}`
        password= `password-${Math.random()}`
        participatedPolls = `partipolls-${Math.random()}`
        proposedPolls = ['k89236423894y2348', '12323']
        userRole = 'citizen'

        const user = await User.create({cityId, fullname, address, documentId, email, imgDocId, password, participatedPolls, proposedPolls, userRole})
        userId = user.id

        const poll = await Poll.create({ cityId, authorId, question, optionA, optionB, description, expiryDate, imagePoll, positives, negatives, pollStatus })
        pollId = poll.id

    })
    
    it('should succeed on correct data', async () => {
        const result = await logic.votePoll(userId, pollId, 'positive')
        expect(result).to.exist

        const poll = await Poll.findById(pollId)
        expect(poll).to.exist
        expect(poll.positives).to.equal(++positives)
    })

/*      it('should fail on non-existing poll', () => {
        id = '5d5d5530531d455f75da9fF9'

        return logic.votePoll(id, body )
            .then(() => { throw new Error('should not reach this point') })
            .catch(({ message }) => expect(message).to.equal(`poll with id ${id} does not exist`))
    }) 
 */
    after(() => mongoose.disconnect())
})
const validate = require('../../../utils/validate')
const { models } = require('democratum-data')
const { User, Poll } = models

/**
 * Citizen votes on poll.
 * 
 * @param {} 
 * @param {}
 * 
 * @returns {}
 */

module.exports = function (userId, pollId, vote) {
    validate.string(userId, 'userId')
    validate.string(pollId, 'pollId')
    validate.string(vote, 'vote')
    
    return (async () => {
        //Validate ID's
        const user = await User.findById(userId)
        if (!user) throw new Error(`user with id ${userId} does not exist`)

        const poll = await Poll.findById(pollId)
        if(!poll) throw new Error(`poll with id ${pollId} does not exist`)

        const alreadyVoted = user.participatedPolls.find(poll => {
            return poll.id === pollId
        })
        //Validate if User already vote
        if(alreadyVoted) throw Error(`user already voted in poll ${pollId}`)
        user.participatedPolls.push(pollId)
        //Votes depending on user vote
        if(vote === "positive"){
            poll.positives++
        }
        if(vote === "negative"){
            poll.negatives++
        } 

        //Saving to DB
        await poll.save()
        await user.save()

        return { pollId, positives: poll.positives, negatives: poll.negatives }
    })()
}

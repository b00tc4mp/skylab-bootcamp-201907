const validate = require('../../../utils/validate')
const { models } = require('democratum-data')
const { Poll } = models

/**
 * Creates a new poll. Users with the role 'citizen' only can create polls with status 'pending'.
 * 
 * 
 * @param {String} cityId
 * @param {String} authorId
 * @param {String} question
 * @param {String} optionA
 * @param {String} optionB
 * @param {String} description
 * @param {Date} expiryDate
 * @param {String} imagePoll
 * @param {Number} positives
 * @param {Number} negatives
 * @param {String} pollStatus
 *
 * @returns {Promise}
 */

module.exports = function(cityId, authorId, question, optionA, optionB, description, expiryDate, imagePoll, positives, negatives, pollStatus, id) {

    /* validate.string(name, 'name')
    validate.string(surname, 'surname')
    validate.string(email, 'username')
    validate.email(email, 'username') */
    
    return (async () => {
        const poll = await Poll.findOne({ id })
        
        if (poll) throw Error('Poll already exists.')

        // Hauria de buscar l'usuari i verificar que es admin --> status approved
        // Si no es admin el pollStatus queda amb pending

        await Poll.create({cityId, authorId, question, optionA, optionB, description, expiryDate, imagePoll, positives, negatives, pollStatus, id})

        return poll
    })()
}
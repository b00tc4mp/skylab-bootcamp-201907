const logic = require('../..')
const bcrypt = require('bcrypt')
const { expect } = require('chai')
const { models , mongoose } = require('democratum-data')
const { User } = models

describe('logic - update user', () => {

    before(() =>  mongoose.connect('mongodb://localhost/democratum-test', { useNewUrlParser: true }))

    let cityId, fullname, address, documentId, email, imgDocId, password, participatedPolls, proposedPolls, userRole

    beforeEach(async () => {

        await User.deleteMany()

        cityId = `city-${Math.random()}`
        fullname = `fullname-${Math.random()}`
        address = `address-${Math.random()}`
        documentId = `documentid-${Math.random()}@domain.com`
        email = `email@-${Math.random()}.com`
        imgDocId = `imgdocid-${Math.random()}`
        password = `password-${Math.random()}`
        participatedPolls = `partipolls-${Math.random()}`
        proposedPolls = `proposed-${Math.random()}`
        userRole = 'citizen'

        body = {
            cityId: `city-${Math.random()}`,
            fullname: `fullname-${Math.random()}`,
            address: `address-${Math.random()}`,
            documentId: `documentid-${Math.random()}@domain.com`,
            email: `email@-${Math.random()}.com`,
            imgDocId: `imgdocid-${Math.random()}`,
            password: `password-${Math.random()}`,
            participatedPolls: `partipolls-${Math.random()}`,
            proposedPolls: `proposed-${Math.random()}`,
            userRole: 'citizen'
        }

        
            const hash = await bcrypt.hash(password, 10)
            const user = await User.create({ cityId, fullname, address, documentId, email, imgDocId, password: hash, participatedPolls, proposedPolls, userRole })
            id = user.id
    })

    it('should succeed on correct data', async () =>{
        const response = await logic.updateUser(id, body)

            expect(response).to.exist
            return ( async () => {
            
            const user = await User.findById(id)
           
                expect(user).to.exist
                expect(user.cityId).to.equal(body.cityId)
                expect(user.fullname).to.equal(body.fullname)
                expect(user.address).to.equal(body.address)
                expect(user.documentId).to.equal(body.documentId)
                expect(user.email).to.equal(body.email)
                expect(user.imgDocId).to.equal(body.imgDocId)
                expect(user.password).to.exist
                expect(user.participatedPolls).to.equal(body.participatedPolls)
                expect(user.proposedPolls).to.equal(body.proposedPolls)
                expect(user.userRole).to.equal(body.userRole)
        })
    })

    it('should fail on non-existing user', async () => {
       try {

        await logic.updateUser('5d5d5530531d455f75da9fF9', body)

       } catch({ message }){
           
           expect(message).to.equal('user with id 5d5d5530531d455f75da9fF9 does not exist')
     }
    })

    after(() => mongoose.disconnect())
})

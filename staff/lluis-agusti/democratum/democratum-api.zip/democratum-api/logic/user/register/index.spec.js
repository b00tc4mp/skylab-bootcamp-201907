const logic = require('../..')
const { expect } = require('chai')
const { models , mongoose } = require('democratum-data')
const bcrypt = require('bcryptjs')
const { User } = models

describe.only('logic - register citizen', () => {

    before(() =>  mongoose.connect('mongodb://localhost/democratum-test', { useNewUrlParser: true }))
        
    let cityId, fullname, address, documentId, email, imgDocId, password, participatedPolls, proposedPolls, userRole

    beforeEach(async () => {

        await User.deleteMany()

        cityId = `cityid-${Math.random()}`
        fullname = `fullname-${Math.random()}`
        address = `address-${Math.random()}`
        documentId = `documentid-${Math.random()}@domain.com`
        email = `email@-${Math.random()}.com`
        imgDocId = `imgdocid-${Math.random()}`
        password = `password-${Math.random()}`
        participatedPolls = [`partipolls-${Math.random()}`]
        proposedPolls = ['k89236423894y2348', '12323']
        userRole = 'citizen'

    })

    it('should succeed on correct data', async () => {
        const result = await logic.registerUser(cityId, fullname, address, documentId, email, imgDocId, password, participatedPolls, proposedPolls, userRole)
            
        expect(result).to.exist
        const user = await User.findOne({ email })
    
        expect(user).to.exist
        expect(user.cityId).to.equal(cityId)
        expect(user.fullname).to.equal(fullname)
        expect(user.address).to.equal(address)
        expect(user.documentId).to.equal(documentId)
        expect(user.email).to.equal(email)
        expect(user.imgDocId).to.equal(imgDocId)
        //expect(user.password).to.equal(password)
        //expect(user.participatedPolls).to.equal(participatedPolls) // me dice que debe ser array
        //expect(user.proposedPolls).to.equal(proposedPolls) // me dice que debe ser array
        //expect(user.userRole).to.equal(userRole)

        const match = await bcrypt.compare(password, user.password)

        expect(match).to.be.true
    })

    it('should fail if the mail already exists', async () => {
        await User.create({ cityId, fullname, address, documentId, email, imgDocId, password, participatedPolls, proposedPolls, userRole })
            try{
                await logic.registerUser(cityId, fullname, address, documentId, email, imgDocId, password, participatedPolls, proposedPolls, userRole)
                throw new Error('should not reach this point')
            }catch(error) {
                    expect(error).to.exist
                    expect(error.message).to.equal(`user with email ${email} already exists`)
                }
    })

    it('should fail on empty cityId', async () => {
        try {
            await logic.registerUser("", fullname, address, documentId, email, imgDocId, password, participatedPolls, proposedPolls, userRole)
            throw new Error('should not reach this point')
        } catch(error) {
                expect(error).to.exist
                expect(error.message).to.equal('User validation failed: cityId: Path `cityId` is required.')
        }
    })

    it('should fail on empty fullname', async () => {
        try {
            await logic.registerUser(cityId, "", address, documentId, email, imgDocId, password, participatedPolls, proposedPolls, userRole)
            throw new Error('should not reach this point')
        } catch(error) {
                expect(error).to.exist
                expect(error.message).to.equal('User validation failed: fullname: Path `fullname` is required.')
        }
    })

    it('should fail on empty address', async () => {
        try {
            await logic.registerUser(cityId, fullname, "", documentId, email, imgDocId, password, participatedPolls, proposedPolls, userRole)
            throw new Error('should not reach this point')
        } catch(error) {
                expect(error).to.exist
                expect(error.message).to.equal('User validation failed: fullname: Path `fullname` is required.')
        }
    })

    
    it('should fail on empty email', () => {
        email = ''
        expect(() => logic.registerUser(cityId, fullname, address, documentId, "", imgDocId, password, participatedPolls, proposedPolls, userRole)).to.throw(Error, `e-mail is empty or blank`)
    })
    

    it('should fail on empty documentId', async () => {
        try {
            await logic.registerUser(cityId, fullname, address, "", email, imgDocId, password, participatedPolls, proposedPolls, userRole)
            throw new Error('should not reach this point')
        } catch(error) {
                expect(error).to.exist
                expect(error.message).to.equal('User validation failed: documentId: Path `documentId` is required.')
        }
    })

    it('should fail on missing e-mail', () => {
        email = ''
        expect(() => logic.registerUser(cityId, fullname, address, documentId, "", imgDocId, password, participatedPolls, proposedPolls, userRole)).to.throw(Error, `e-mail is empty or blank`)
    })

    




    after(() => mongoose.disconnect())
})
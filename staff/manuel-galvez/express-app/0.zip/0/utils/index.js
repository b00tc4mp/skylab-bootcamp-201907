module.exports = {
    validate: require('./validate'),
    call: require('./call'),
    parseBody: require('./parse-body')
}
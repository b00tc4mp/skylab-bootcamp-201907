module.exports = function(path) {
    return `<p>
        User successfully registered, you can now proceed to <a href="${path}">login</a>.
    </p>`
}